public class xoropertion {
    public static void main(String[] args) {
        int a=5;
        int b=3;
        System.out.println(a^b);
    }
}
