class evennumber{
    public static void main(String[] args){
    int num=2;
    while(num<=20){
        System.out.println("num"+num);
        num+=2;
    }
}}
