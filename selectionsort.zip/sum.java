public class sum{
    public static void main(String[] argss){
    int a=5;
    int b=10;
    int sum=a+b;
    System.out.println("sum:"+sum);}}
    
