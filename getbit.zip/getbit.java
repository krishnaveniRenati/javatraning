class getbit{
    public static void main(String[] args){
    int n=5;
    int i=2;
    int bitmask = 1<<i;
    if((n&(bitmask))!=0){
        System.out.println("bit is 1");
    }else{
        System.out.println("bit is 0");
    }
}}