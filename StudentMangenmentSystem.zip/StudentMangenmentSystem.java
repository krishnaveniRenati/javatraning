import java.util.ArrayList;
import java.util.Scanner;
class Student {
    String name;
    int rollNo;
    String course;
    public Student(String name, int rollNo, String course) {
        this.name = name;
        this.rollNo = rollNo;
        this.course = course;
    }
    public void display() {
        System.out.println("Roll No: " + rollNo + ", Name: " + name + ", Course: " + course);
    }
}
public class StudentMangenmentSystem{
    static ArrayList<Student> students = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);
    public static void addStudent() {
        System.out.print("Enter Name: ");
        String name = sc.nextLine();
        System.out.print("Enter Roll No: ");
        int rollNo = sc.nextInt();
        sc.nextLine(); 
        System.out.print("Enter Course: ");
        String course = sc.nextLine();

        students.add(new Student(name, rollNo, course));
        System.out.println("Student added successfully!");
    }
    public static void removeStudent() {
        System.out.print("Enter Roll No to remove: ");
        int rollNo = sc.nextInt();
        boolean removed = students.removeIf(s -> s.rollNo == rollNo);
        if (removed) {
            System.out.println("Student removed successfully!");
        } else {
            System.out.println("Student not found.");
        }
    }
    public static void displayStudents() {
        if (students.isEmpty()) {
            System.out.println("No students to display.");
            return;
        }
        System.out.println("\n--- Student List ---");
        for (Student s : students) {
            s.display();
        }
    }
    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("\n--- Student Management System ---");
            System.out.println("1. Add Student");
            System.out.println("2. Remove Student");
            System.out.println("3. Display Students");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1: addStudent(); break;
                case 2: removeStudent(); break;
                case 3: displayStudents(); break;
                case 4: System.out.println("Exiting..."); break;
                default: System.out.println("Invalid choice!"); 
            }
        } while (choice != 4);
    }
}