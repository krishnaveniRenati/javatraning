public class Secondlargest {
    public static void main(String[] args) {
        int[] arr={10,20,30,40};
        //selection sort
        for(int i=0;i<arr.length-1;i++){
            int max=i;
            for(int j=i+1;j<arr.length;j++){
                if(arr[j]>arr[max]){
                    max=j;

                }
            }
            int temp= arr[i];
            arr[i]=arr[max];
            arr[max]=temp;

        }
        System.err.println(" Second larget="+ arr[1]);
    }
}
