public class leftshift {
    public static void main(String[] args) {
        int x =4;
        System.err.println(x<<2);
    }
    
}
