class andopertion{
    public static void main(String[] args) {
        int a=6;
        int b=3;
        System.out.println(a&b);
    }
}